# Hand-Gesture-Recognition-Python-OPENCV

This python script can be used to analyze hand gestures by contour detection, and convex hull of hand palm using opencv library used for computer vision processes.

Built using OpenCV 2.4.12 on Python 2.7.10 
Works on OpenCV 2.4.x and Python 2.x  

#

Run On Server:
python gesture.py

# See Also
Python Script to detect skin in given module [Blob-WEbcam]

Run on Server:
python skindetectorhk.py
