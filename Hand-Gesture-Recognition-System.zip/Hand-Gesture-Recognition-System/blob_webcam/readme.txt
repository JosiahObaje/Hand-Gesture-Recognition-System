

Python Script to detect Hnad gesture (movement) in given module [Blob-WEbcam]

Run on Server:
python skindetectorhk.py

For more Info from Uriel Global:
Call: Obaje Josiah: 09150464707, 09153462008